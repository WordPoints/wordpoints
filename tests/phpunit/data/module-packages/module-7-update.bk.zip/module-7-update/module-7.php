<?php

/**
 * Module Name: Module 7
 * Author:      J.D. Grimes
 * Author URI:  https://codesymphony.co/
 * Module URI:  https://codesymphony.co/
 * Version:     1.0.1
 * License:     GPLv2+
 * Description: Description.
 * Server:      wordpoints.org
 * ID:          7
 *
 * @package Module_7
 */

// Code here.

// EOF
