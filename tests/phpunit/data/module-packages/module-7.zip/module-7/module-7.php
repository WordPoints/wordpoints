<?php

/**
 * Extension Name: Module 7
 * Author:         J.D. Grimes
 * Author URI:     https://codesymphony.co/
 * Extension URI:  https://codesymphony.co/
 * Version:        1.0.0
 * License:        GPLv2+
 * Description:    Description.
 * Server:         wordpoints.org
 * ID:             7
 *
 * @package Module7
 */

// Code here.

// EOF
