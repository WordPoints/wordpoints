<?php

/**
 * Module Name: Module 8
 * Author:      J.D. Grimes
 * Author URI:  https://codesymphony.co/
 * Module URI:  https://codesymphony.co/
 * Version:     1.0.0
 * License:     GPLv2+
 * Description: Description.
 *
 * @package Module_8
 */

// Code here.

// EOF
